autos = []

def agregar_auto():
    patente = input("Ingrese la patente del auto: ")
    modelo = input("Ingrese el modelo del auto: ")
    autos.append({"patente": patente, "modelo": modelo})
    print("Auto agregado correctamente.")

def listar_autos():
    if not autos:
        print("No hay autos registrados.")
        return
    print("\nLista de autos:")
    for i, auto in enumerate(autos, 1):
        print(f"{i}. Patente: {auto['patente']}, Modelo: {auto['modelo']}")

def buscar_auto():
    patente_buscar = input("Ingrese la patente del auto a buscar: ")
    encontrados = [a for a in autos if a["patente"].lower() == patente_buscar.lower()]
    if encontrados:
        for auto in encontrados:
            print(f"Encontrado - Patente: {auto['patente']}, Modelo: {auto['modelo']}")
    else:
        print("Auto no encontrado.")

def menu_autos():
    while True:
        print("\n--- GESTIÓN DE AUTOS ---")
        print("1. Agregar auto")
        print("2. Listar autos")
        print("3. Buscar auto")
        print("4. Volver")
        opcion = input("Elige una opción: ")
        if opcion == "1":
            agregar_auto()
        elif opcion == "2":
            listar_autos()
        elif opcion == "3":
            buscar_auto()
        elif opcion == "4":
            break
        else:
            print("Opción inválida, intenta de nuevo.")

if __name__ == "__main__":
    menu_autos()
