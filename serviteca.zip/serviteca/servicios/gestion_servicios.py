servicios = []

def agregar_servicio():
    descripcion = input("Ingrese la descripción del servicio: ")
    auto_patente = input("Ingrese la patente del auto para el servicio: ")
    servicios.append({"descripcion": descripcion, "auto_patente": auto_patente})
    print("Servicio agregado correctamente.")

def listar_servicios():
    if not servicios:
        print("No hay servicios registrados.")
        return
    print("\nLista de servicios:")
    for i, servicio in enumerate(servicios, 1):
        print(f"{i}. Auto: {servicio['auto_patente']}, Descripción: {servicio['descripcion']}")

def buscar_servicios_por_auto():
    patente_buscar = input("Ingrese la patente del auto para buscar servicios: ")
    encontrados = [s for s in servicios if s["auto_patente"].lower() == patente_buscar.lower()]
    if encontrados:
        print(f"Servicios para auto {patente_buscar}:")
        for servicio in encontrados:
            print(f"- {servicio['descripcion']}")
    else:
        print("No se encontraron servicios para ese auto.")

def menu_servicios():
    while True:
        print("\n--- GESTIÓN DE SERVICIOS ---")
        print("1. Agregar servicio")
        print("2. Listar servicios")
        print("3. Buscar servicios por auto")
        print("4. Volver")
        opcion = input("Elige una opción: ")
        if opcion == "1":
            agregar_servicio()
        elif opcion == "2":
            listar_servicios()
        elif opcion == "3":
            buscar_servicios_por_auto()
        elif opcion == "4":
            break
        else:
            print("Opción inválida, intenta de nuevo.")

if __name__ == "__main__":
    menu_servicios()
