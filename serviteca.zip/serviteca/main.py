from autos import gestion_autos
from clientes import gestion_clientes
from servicios import gestion_servicios

def menu_principal():
    while True:
        print("\n--- SERVITECA ---")
        print("1. Gestionar autos")
        print("2. Gestionar clientes")
        print("3. Gestionar servicios")
        print("4. Salir")
        opcion = input("Elige una opción: ")
        if opcion == "1":
            gestion_autos.menu_autos()       # Aquí cambias menu() por menu_autos()
        elif opcion == "2":
            gestion_clientes.menu_clientes() # Cambia menu() por menu_clientes()
        elif opcion == "3":
            gestion_servicios.menu_servicios() # Cambia menu() por menu_servicios()
        elif opcion == "4":
            print("Saliendo del programa..")
            break
        else:
            print("Opción inválida, intenta de nuevo.")

if __name__ == "__main__":
    menu_principal()
