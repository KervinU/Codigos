clientes = []

def agregar_cliente():
    nombre = input("Ingrese el nombre del cliente: ")
    telefono = input("Ingrese el teléfono del cliente: ")
    clientes.append({"nombre": nombre, "telefono": telefono})
    print("Cliente agregado correctamente.")

def listar_clientes():
    if not clientes:
        print("No hay clientes registrados.")
        return
    print("\nLista de clientes:")
    for i, cliente in enumerate(clientes, 1):
        print(f"{i}. Nombre: {cliente['nombre']}, Teléfono: {cliente['telefono']}")

def buscar_cliente():
    nombre_buscar = input("Ingrese el nombre del cliente a buscar: ")
    encontrados = [c for c in clientes if c["nombre"].lower() == nombre_buscar.lower()]
    if encontrados:
        for cliente in encontrados:
            print(f"Encontrado - Nombre: {cliente['nombre']}, Teléfono: {cliente['telefono']}")
    else:
        print("Cliente no encontrado.")

def menu_clientes():
    while True:
        print("\n--- GESTIÓN DE CLIENTES ---")
        print("1. Agregar cliente")
        print("2. Listar clientes")
        print("3. Buscar cliente")
        print("4. Volver")
        opcion = input("Elige una opción: ")
        if opcion == "1":
            agregar_cliente()
        elif opcion == "2":
            listar_clientes()
        elif opcion == "3":
            buscar_cliente()
        elif opcion == "4":
            break
        else:
            print("Opción inválida, intenta de nuevo.")

if __name__ == "__main__":
    menu_clientes()
